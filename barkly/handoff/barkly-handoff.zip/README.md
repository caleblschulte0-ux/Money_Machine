# Barkly handoff package — for ChatGPT

Drop these into a ChatGPT conversation. Everything is self-contained; ChatGPT
needs no repo access.

## What to attach

| File | Why |
|---|---|
| `BARKLY_FOR_CHATGPT.md` | **The brief.** Product, locked character, everything built, honest gaps, and the specific asks. Attach this first. |
| `barkly-concept.png` | The locked character sheet — the visual reference for any art it generates. |
| `screenshots/*.png` | The app actually running. Attach as many as you like; `02`, `05`, and `06` show the most. |
| `CODE_SNAPSHOT.md` | Every source file concatenated. Only needed if you want a code review. |

## Suggested opening message

> Here's the full brief for Barkly, an AI virtual dog app I'm building
> (`BARKLY_FOR_CHATGPT.md`), the locked character sheet you originally
> generated, and screenshots of it running. Read the brief, then:
> 1. Generate the nine pose renders described in §7a, matching the sheet exactly.
> 2. Give me the honest product review in §7b.

If ChatGPT can only take one file, `BARKLY_FOR_CHATGPT.md` plus the concept
sheet is enough for the art ask.

## Note

Everything here is generated from the repo — regenerate after big changes so
the handoff never goes stale.
